# Robotics_GA (Heriot-Watt University - Robotics)


This repository contains a simple project that will support your studies on Genetic Algorithm using a simulated environtment (Webots).

The instructions will be delivered during the laboratory sessions.
